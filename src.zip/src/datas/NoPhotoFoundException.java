package datas;

public class NoPhotoFoundException extends Exception {
	private static final long serialVersionUID = 0;
}
