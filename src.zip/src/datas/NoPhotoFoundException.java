package datas;

/**
 * Classe definnissant l'exception renvoyee lorsqu'une {@link Photo} n'est pas trouvee.
 * @author FRETAY Juliette et LE POLLES--POTIN Leandre - Groupe 1C
 */
public class NoPhotoFoundException extends Exception {
	private static final long serialVersionUID = 0;
}
